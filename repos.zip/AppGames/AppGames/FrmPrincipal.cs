﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppGames
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            Games game = new Games();
            List<Games> jogo = game.listagames();
            dgvJogo.DataSource = jogo;
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            DialogResult dialog = new DialogResult();
            dialog = MessageBox.Show("Deseja realmente sair do aplicativo?!", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialog == DialogResult.Yes)
            {
                Application.Exit();
            } 
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            if (textNome.Text == "" && textDesenvolvedora.Text == "")
            {
                MessageBox.Show("Preencha o formulário!");
                this.textNome.Focus();
            }
            else
            {
                Games game = new Games();
                if (game.RegistroRepetido(textNome.Text) != false)
                {
                    MessageBox.Show("Este jogo já foi cadastrado!");
                    this.textNome.Focus();
                }
                else
                {
                    int nota = Convert.ToInt32(textNota.Text);
                    game.Inserir(textNome.Text, textDesenvolvedora.Text, textAno.Text, nota);
                    MessageBox.Show("Jogo cadastrado com sucesso!");
                    List<Games> games = game.listagames();
                    dgvJogo.DataSource = games;
                    textNome.Text = "";
                    textDesenvolvedora.Text = "";
                    textAno.Text = "";
                    textNota.Text = "";
                    this.textNome.Focus();
                }
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            int Id = Convert.ToInt32(textId.Text.Trim());
            int nota = Convert.ToInt32(textNota.Text);
            Games game = new Games();
            game.Atualizar(Id, textNome.Text, textDesenvolvedora.Text, textAno.Text, nota);
            MessageBox.Show("Jogo atualizado com sucesso!");
            List<Games> games = game.listagames();
            dgvJogo.DataSource = games;
            textId.Text = "";
            textNome.Text = "";
            textDesenvolvedora.Text = "";
            textAno.Text = "";
            textNota.Text = "";
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
            this.textNome.Focus();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            int Id = Convert.ToInt32(textId.Text.Trim());
            Games game = new Games();
            game.Excluir(Id);
            MessageBox.Show("Jogo deletado com sucesso!");
            List<Games> games = game.listagames();
            dgvJogo.DataSource = games;
            textId.Text = "";
            textNome.Text = "";
            textDesenvolvedora.Text = "";
            textAno.Text = "";
            textNota.Text = "";
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
            this.textNome.Focus();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            if (textId.Text == "")
            {
                MessageBox.Show("Por favor digite um Id!");
            }
            else
            {
                int Id = Convert.ToInt32(textId.Text.Trim());
                Games game = new Games();
                game.Localizar(Id);
                textNome.Text = game.nome;
                textDesenvolvedora.Text = game.desenvolvedora;
                textAno.Text = game.ano;
                textNota.Text = Convert.ToString(game.nota);
                btnEditar.Enabled = true;
                btnExcluir.Enabled = true;


            }
        }

        private void dgvJogo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvJogo.Rows[e.RowIndex];
                row.Selected = true;
                textId.Text = row.Cells[0].Value.ToString();
                textNome.Text = row.Cells[1].Value.ToString();
                textDesenvolvedora.Text = row.Cells[2].Value.ToString();
                textAno.Text = row.Cells[3].Value.ToString();
                textNota.Text = row.Cells[4].Value.ToString();
                btnEditar.Enabled = true;
                btnExcluir.Enabled = true;
            }
        }
    }
}
