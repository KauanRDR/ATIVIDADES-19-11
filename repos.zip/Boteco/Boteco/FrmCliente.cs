﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Boteco
{
    public partial class FrmCliente : Form
    {
        public FrmCliente()
        {
            InitializeComponent();
        }

        private void FrmCliente_Load(object sender, EventArgs e)
        {
            Cliente cliente = new Cliente();
            List<Cliente> clientes = cliente.listacliente();
            dgvCliente.DataSource = clientes;
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            DialogResult dialog = new DialogResult();
            dialog = MessageBox.Show("Deseja realmente sair do aplicativo?!", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialog == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            int Id = Convert.ToInt32(textId.Text.Trim());
            int nota = Convert.ToInt32(textNota.Text);
            Games game = new Games();
            game.Atualizar(Id, textNome.Text, textDesenvolvedora.Text, textAno.Text, nota);
            MessageBox.Show("Jogo atualizado com sucesso!");
            List<Games> games = game.listagames();
            dgvJogo.DataSource = games;
            textId.Text = "";
            textNome.Text = "";
            textDesenvolvedora.Text = "";
            textAno.Text = "";
            textNota.Text = "";
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
            this.textNome.Focus();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
